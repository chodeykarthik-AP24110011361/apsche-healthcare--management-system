const APPS_SCRIPT_URL =
  'https://script.google.com/macros/s/AKfycbxQ-GxlfGvz4TiIGhjpEqprPhknVzGWGRURfSTp30IUPC-jxm2NU8IXUCTtfMUiAxJl/exec';

async function apiCall(action, data = null) {
  if (data === null) {
    const response = await fetch(
      `${APPS_SCRIPT_URL}?action=${encodeURIComponent(action)}`
    );

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
  }

  const formData = new URLSearchParams();

  formData.append(
    'data',
    JSON.stringify({
      action,
      ...data
    })
  );

  const response = await fetch(APPS_SCRIPT_URL, {
    method: 'POST',
    body: formData
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  return response.json();
}

export async function getAppointments() {
  return apiCall('getAppointments');
}

export async function addAppointment(appointment) {
  return apiCall('addAppointment', { appointment });
}

export async function updateAppointment(id, updatedFields) {
  return apiCall('updateAppointment', {
    id,
    updatedFields
  });
}

export async function deleteAppointment(id) {
  return apiCall('deleteAppointment', { id });
}

export async function getMedications() {
  return apiCall('getMedications');
}

export async function addMedication(medication) {
  return apiCall('addMedication', { medication });
}

export async function updateMedication(id, updatedFields) {
  return apiCall('updateMedication', {
    id,
    updatedFields
  });
}

export async function deleteMedication(id) {
  return apiCall('deleteMedication', { id });
}

export async function getPatients() {
  return apiCall('getPatients');
}

export async function addPatient(patient) {
  return apiCall('addPatient', { patient });
}

export async function updatePatient(id, updatedFields) {
  return apiCall('updatePatient', {
    id,
    updatedFields
  });
}

export async function deletePatient(id) {
  return apiCall('deletePatient', { id });
}

export async function generateHealthSummary(patient) {
  return apiCall('generateHealthSummary', {
    patient
  });
}

export async function sendSMS(phone, message) {
  console.log("Sending SMS to:", phone);

  return apiCall("sendSMS", {
    phone,
    message
  });
}