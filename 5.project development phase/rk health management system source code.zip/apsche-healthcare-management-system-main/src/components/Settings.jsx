import React, { useState } from 'react';
import { User, Bell, Shield, Save, Eye, Laptop } from 'lucide-react';
import { mockUserProfile } from '../mockData';
import './Pages.css';

export default function Settings({ theme, toggleTheme }) {
  const [activeTab, setActiveTab] = useState('profile');
  const [profile, setProfile] = useState(mockUserProfile);

  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNotificationToggle = (key) => {
    setProfile(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [key]: !prev.notifications[key]
      }
    }));
  };

  const handleSave = (e) => {
    e.preventDefault();
    alert('System settings and profile updates saved successfully (Mock update).');
  };

  return (
    <div className="settings-page animate-fade-in">
      <div className="glass-panel settings-card" style={{ padding: '0px', overflow: 'hidden' }}>
        
        <div className="settings-grid">
          
          {/* Settings Left Navigation */}
          <div 
            className="settings-sidebar" 
            style={{ 
              padding: '24px 16px', 
              borderRight: '1px solid var(--border)', 
              height: '100%', 
              backgroundColor: 'var(--background)' 
            }}
          >
            <div className="settings-nav">
              <button 
                className={`settings-nav-btn ${activeTab === 'profile' ? 'active' : ''}`}
                onClick={() => setActiveTab('profile')}
              >
                <User size={18} />
                <span>Clinic Profile</span>
              </button>
              
              <button 
                className={`settings-nav-btn ${activeTab === 'notifications' ? 'active' : ''}`}
                onClick={() => setActiveTab('notifications')}
              >
                <Bell size={18} />
                <span>Alerts & Reminders</span>
              </button>

              <button 
                className={`settings-nav-btn ${activeTab === 'system' ? 'active' : ''}`}
                onClick={() => setActiveTab('system')}
              >
                <Laptop size={18} />
                <span>System Configurations</span>
              </button>
            </div>
          </div>

          {/* Settings Right panel form content */}
          <div className="settings-panel">
            <form onSubmit={handleSave}>
              
              {/* Tab 1: Profile Details */}
              {activeTab === 'profile' && (
                <div>
                  <h3 className="settings-section-title">Clinic Profile Details</h3>
                  
                  <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '24px' }}>
                    <img 
                      src={profile.avatar} 
                      alt="Avatar" 
                      style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', border: '3px solid var(--primary-light)' }} 
                    />
                    <div>
                      <button type="button" className="btn btn-sm btn-secondary">Upload New Avatar</button>
                      <p style={{ fontSize: '0.675rem', color: 'var(--text-muted)', marginTop: '4px' }}>PNG, JPG or WEBP formats. Max size 2MB.</p>
                    </div>
                  </div>

                  <div className="settings-form-row">
                    <div className="form-group">
                      <label className="form-label">Full Name</label>
                      <input 
                        type="text" 
                        name="name"
                        className="form-input" 
                        value={profile.name}
                        onChange={handleProfileChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Administrative Role</label>
                      <input 
                        type="text" 
                        name="role"
                        className="form-input" 
                        value={profile.role}
                        onChange={handleProfileChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="settings-form-row">
                    <div className="form-group">
                      <label className="form-label">Facility Center</label>
                      <input 
                        type="text" 
                        name="clinic"
                        className="form-input" 
                        value={profile.clinic}
                        onChange={handleProfileChange}
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">Registered Email</label>
                      <input 
                        type="email" 
                        name="email"
                        className="form-input" 
                        value={profile.email}
                        onChange={handleProfileChange}
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Alerts & Notifications */}
              {activeTab === 'notifications' && (
                <div>
                  <h3 className="settings-section-title">Alert Dispatch Toggles</h3>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginBottom: '24px' }}>
                    Control how medication warnings and patient check-in reminders are dispatched to devices.
                  </p>

                  <div className="toggle-group">
                    <div className="toggle-item">
                      <div className="toggle-label-block">
                        <span className="toggle-title">Email Notification Alerts</span>
                        <span className="toggle-desc">Send automated medication low-stock and appointment briefs to patient logs.</span>
                      </div>
                      <label className="switch">
                        <input 
                          type="checkbox" 
                          checked={profile.notifications.email} 
                          onChange={() => handleNotificationToggle('email')}
                        />
                        <span className="slider"></span>
                      </label>
                    </div>

                    <div className="toggle-item">
                      <div className="toggle-label-block">
                        <span className="toggle-title">Push Notifications</span>
                        <span className="toggle-desc">Show immediate desktop or device alarms when check-ins arrive.</span>
                      </div>
                      <label className="switch">
                        <input 
                          type="checkbox" 
                          checked={profile.notifications.push} 
                          onChange={() => handleNotificationToggle('push')}
                        />
                        <span className="slider"></span>
                      </label>
                    </div>

                    <div className="toggle-item">
                      <div className="toggle-label-block">
                        <span className="toggle-title">SMS Cellphone Warnings</span>
                        <span className="toggle-desc">Deliver critical urgent schedules through cellular message portals.</span>
                      </div>
                      <label className="switch">
                        <input 
                          type="checkbox" 
                          checked={profile.notifications.sms} 
                          onChange={() => handleNotificationToggle('sms')}
                        />
                        <span className="slider"></span>
                      </label>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: System Settings */}
              {activeTab === 'system' && (
                <div>
                  <h3 className="settings-section-title">System Configurations</h3>
                  
                  <div className="settings-form-row">
                    <div className="form-group">
                      <label className="form-label">Auto Refresh Frequency</label>
                      <select className="form-select" style={{ width: '100%', padding: '10px' }}>
                        <option value="1 min">Every minute</option>
                        <option value="5 min">Every 5 minutes</option>
                        <option value="15 min">Every 15 minutes</option>
                        <option value="Manual">Manual reload only</option>
                      </select>
                    </div>

                    <div className="form-group">
                      <label className="form-label">Time Format</label>
                      <select className="form-select" style={{ width: '100%', padding: '10px' }}>
                        <option value="12h">12-hour Standard (AM/PM)</option>
                        <option value="24h">24-hour Military</option>
                      </select>
                    </div>
                  </div>

                  <h3 className="settings-section-title" style={{ marginTop: '30px' }}>Appearance Mode</h3>
                  <div className="toggle-item" style={{ marginBottom: '24px' }}>
                    <div className="toggle-label-block">
                      <span className="toggle-title">System Dark Colors</span>
                      <span className="toggle-desc">Toggle darker high-contrast panel colors.</span>
                    </div>
                    <label className="switch">
                      <input 
                        type="checkbox" 
                        checked={theme === 'dark'} 
                        onChange={toggleTheme}
                      />
                      <span className="slider"></span>
                    </label>
                  </div>
                </div>
              )}

              {/* Footer Save Row */}
              <div 
                style={{ 
                  borderTop: '1px solid var(--border)', 
                  paddingTop: '20px', 
                  display: 'flex', 
                  justifyContent: 'flex-end', 
                  marginTop: '32px' 
                }}
              >
                <button type="submit" className="btn btn-primary">
                  <Save size={16} /> Save Settings
                </button>
              </div>

            </form>
          </div>

        </div>

      </div>
    </div>
  );
}
