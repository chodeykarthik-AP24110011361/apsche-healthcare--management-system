import React, { useState } from 'react';
import { 
  Bell, 
  Search, 
  Menu, 
  ChevronDown, 
  User, 
  LogOut,
  CalendarDays,
  Shield,
  Moon,
  Sun
} from 'lucide-react';
import { mockUserProfile, mockReminders } from '../mockData';
import './Navbar.css';

export default function Navbar({ 
  currentPage, 
  setSidebarOpen, 
  theme, 
  toggleTheme 
}) {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  // Capitalize current page name for header
  const getPageTitle = () => {
    if (!currentPage) return 'Dashboard';
    return currentPage.charAt(0).toUpperCase() + currentPage.slice(1);
  };

  // Get current date string
  const getFormattedDate = () => {
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
    return new Date().toLocaleDateString('en-US', options);
  };

  return (
    <header className="navbar glass-panel">
      <div className="navbar-left">
        {/* Toggle menu on Mobile */}
        <button 
          className="mobile-menu-toggle"
          onClick={() => setSidebarOpen(prev => !prev)}
          aria-label="Open menu"
        >
          <Menu size={22} />
        </button>

        <div className="page-title-area">
          <h1 className="page-title">{getPageTitle()}</h1>
          <span className="current-date">{getFormattedDate()}</span>
        </div>
      </div>

      <div className="navbar-right">
        {/* Search Bar - Aesthetic Only */}
        <div className="search-wrapper">
          <Search className="search-icon" size={18} />
          <input 
            type="text" 
            placeholder="Search records, appointments..." 
            className="search-input" 
          />
        </div>

        {/* Dark Mode Switcher */}
        <button 
          className="theme-toggle-btn"
          onClick={toggleTheme}
          title={theme === 'dark' ? "Switch to Light Theme" : "Switch to Dark Theme"}
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>

        {/* Notifications Icon and Dropdown */}
        <div className="navbar-action-container">
          <button 
            className={`navbar-action-btn ${showNotifications ? 'active' : ''}`}
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfileMenu(false);
            }}
            title="Notifications"
          >
            <Bell size={20} />
            <span className="notification-badge-dot" />
          </button>

          {showNotifications && (
            <div className="dropdown-panel notifications-dropdown animate-fade-in">
              <div className="dropdown-header">
                <h3>Upcoming Reminders</h3>
                <span className="badge badge-info">{mockReminders.length} Active</span>
              </div>
              <ul className="reminders-list">
                {mockReminders.map((reminder) => (
                  <li key={reminder.id} className={`reminder-item urgency-${reminder.urgency.toLowerCase()}`}>
                    <div className="reminder-dot" />
                    <div className="reminder-details">
                      <p className="reminder-title">{reminder.title}</p>
                      <div className="reminder-time-meta">
                        <CalendarDays size={12} />
                        <span>{reminder.time}</span>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="dropdown-footer">
                <button onClick={() => setShowNotifications(false)}>Dismiss All</button>
              </div>
            </div>
          )}
        </div>

        {/* Profile Dropdown */}
        <div className="navbar-action-container">
          <button 
            className="profile-trigger-btn"
            onClick={() => {
              setShowProfileMenu(!showProfileMenu);
              setShowNotifications(false);
            }}
          >
            <img 
              src={mockUserProfile.avatar} 
              alt={mockUserProfile.name} 
              className="user-avatar"
            />
            <div className="user-info-text">
              <span className="user-name">{mockUserProfile.name}</span>
              <span className="user-role">{mockUserProfile.role}</span>
            </div>
            <ChevronDown size={16} className="chevron-icon" />
          </button>

          {showProfileMenu && (
            <div className="dropdown-panel profile-dropdown animate-fade-in">
              <div className="profile-menu-header">
                <p className="profile-menu-name">{mockUserProfile.name}</p>
                <p className="profile-menu-clinic">{mockUserProfile.clinic}</p>
              </div>
              <ul className="profile-menu-list">
                <li>
                  <button onClick={() => { setShowProfileMenu(false); }}>
                    <User size={16} />
                    <span>My Profile</span>
                  </button>
                </li>
                <li>
                  <button onClick={() => { setShowProfileMenu(false); }}>
                    <Shield size={16} />
                    <span>Security Portal</span>
                  </button>
                </li>
                <li className="menu-divider" />
                <li>
                  <button className="logout-btn" onClick={() => { setShowProfileMenu(false); }}>
                    <LogOut size={16} />
                    <span>Sign Out</span>
                  </button>
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
