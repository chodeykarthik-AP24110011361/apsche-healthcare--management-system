import React from 'react';
import { 
  Users, 
  Calendar, 
  Pill, 
  Bell, 
  ArrowUpRight, 
  ArrowDownRight, 
  Clock, 
  Check, 
  ChevronRight,
  TrendingUp,
  AlertTriangle
} from 'lucide-react';
import './Pages.css';

export default function Dashboard({ 
  stats, 
  appointments, 
  medications, 
  reminders,
  onCheckIn, 
  onTakeDose,
  setCurrentPage 
}) {
  // Get today's date formatted to match mock data (YYYY-MM-DD)
  const todayStr = new Date().toISOString().split('T')[0];

const uniquePatients = new Set([
  ...appointments.map(apt =>
    apt.patientName?.trim().toLowerCase()
  ),

  ...medications.map(med =>
    med.patientName?.trim().toLowerCase()
  )
].filter(Boolean)).size;

  // Filter today's appointments
  const todaysList = appointments.filter(apt => apt.date === todayStr);
  const pendingApts = todaysList.filter(apt => apt.status !== 'Completed' && apt.status !== 'Cancelled');

  return (
    <div className="dashboard-view animate-fade-in">
      
      {/* 1. Statistics Grid */}
      <div className="stats-grid">
        {/* Card 1: Total Patients */}
        <div className="glass-panel stat-card">
          <div className="stat-card-header">
            <div className="stat-icon-wrapper blue">
              <Users size={22} />
            </div>
            <span className={`stat-trend ${stats.totalPatients.trend === 'up' ? 'positive' : 'negative'}`}>
              {stats.totalPatients.change}
              {stats.totalPatients.trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            </span>
          </div>
          <div className="stat-card-content">
            <h3 className="stat-value">{uniquePatients}</h3>
            <p className="stat-label">Total Patients Managed</p>
            <p className="stat-subtext">{stats.totalPatients.timeframe}</p>
          </div>
        </div>

        {/* Card 2: Today's Appointments */}
        <div className="glass-panel stat-card">
          <div className="stat-card-header">
            <div className="stat-icon-wrapper green">
              <Calendar size={22} />
            </div>
            <span className="stat-trend neutral">
              {stats.todaysAppointments.completed} / {stats.todaysAppointments.value} Done
            </span>
          </div>
          <div className="stat-card-content">
            <h3 className="stat-value">{stats.todaysAppointments.value}</h3>
            <p className="stat-label">Today's Appointments</p>
            {/* Progress bar */}
            <div className="progress-bar-container">
              <div 
                className="progress-bar green" 
                style={{ width: `${(stats.todaysAppointments.completed / stats.todaysAppointments.value) * 100}%` }}
              />
            </div>
            <p className="stat-subtext">{stats.todaysAppointments.pending} slots remaining</p>
          </div>
        </div>

        {/* Card 3: Active Medications */}
        <div className="glass-panel stat-card">
          <div className="stat-card-header">
            <div className="stat-icon-wrapper teal">
              <Pill size={22} />
            </div>
            <span className="stat-trend positive">
              <TrendingUp size={14} /> {stats.activeMedications.adherence} Adherence
            </span>
          </div>
          <div className="stat-card-content">
            <h3 className="stat-value">{stats.activeMedications.value}</h3>
            <p className="stat-label">Active Prescriptions</p>
            <p className="stat-subtext">Monitored adherence score</p>
          </div>
        </div>

        {/* Card 4: Upcoming Reminders */}
        <div className="glass-panel stat-card">
          <div className="stat-card-header">
            <div className="stat-icon-wrapper orange">
              <Bell size={22} />
            </div>
            {stats.upcomingReminders.critical > 0 && (
              <span className="stat-trend critical">
                <AlertTriangle size={14} /> {stats.upcomingReminders.critical} Urgent
              </span>
            )}
          </div>
          <div className="stat-card-content">
            <h3 className="stat-value">{stats.upcomingReminders.value}</h3>
            <p className="stat-label">Pending Reminders</p>
            <p className="stat-subtext">Calculated from live health records</p>
          </div>
        </div>
      </div>

      {/* 2. Main Dashboard Content Area */}
      <div className="dashboard-layout">
        
        {/* Left Column: Appointments & Activity */}
        <div className="dashboard-main-col">
          {/* Today's Schedule Card */}
          <div className="glass-panel content-card">
            <div className="card-header">
              <div>
                <h2>Today's Patient Schedule</h2>
                <p className="card-subtitle">Real-time check-in and session coordinator</p>
              </div>
              <button className="btn-text" onClick={() => setCurrentPage('appointments')}>
                View All Appointments <ChevronRight size={16} />
              </button>
            </div>

            <div className="appointments-list-widget">
              {todaysList.length === 0 ? (
                <div className="empty-widget-state">
                  <Calendar size={40} className="empty-icon" />
                  <p>No appointments scheduled for today.</p>
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="widget-table">
                    <thead>
                      <tr>
                        <th>Time</th>
                        <th>Patient</th>
                        <th>Department & Doctor</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {todaysList.map((apt) => (
                        <tr key={apt.id}>
                          <td className="time-col">
                            <Clock size={14} />
                            <span>{apt.time}</span>
                          </td>
                          <td>
                            <div className="patient-cell">
                              <span className="patient-name">{apt.patientName}</span>
                              <span className="patient-id">{apt.patientId}</span>
                            </div>
                          </td>
                          <td>
                            <div className="dept-cell">
                              <span className="dept-name">{apt.department}</span>
                              <span className="doc-name">{apt.doctorName}</span>
                            </div>
                          </td>
                          <td>
                            <span className={`badge ${
                              apt.status === 'Completed' ? 'badge-success' : 
                              apt.status === 'Checked-In' ? 'badge-info' : 
                              apt.status === 'Cancelled' ? 'badge-danger' : 
                              'badge-warning'
                            }`}>
                              {apt.status}
                            </span>
                          </td>
                          <td>
                            {apt.status === 'Confirmed' ? (
                              <button 
                                className="btn btn-sm btn-primary-light"
                                onClick={() => onCheckIn(apt.id)}
                              >
                                Check In
                              </button>
                            ) : apt.status === 'Checked-In' ? (
                              <button className="btn btn-sm btn-success-light" disabled>
                                <Check size={14} /> Waiting
                              </button>
                            ) : (
                              <span className="action-completed-label">-</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Medications & Reminders */}
        <div className="dashboard-side-col">
          {/* Daily Medication Tracker */}
          <div className="glass-panel content-card">
            <div className="card-header">
              <div>
                <h2>Medication Tracker</h2>
                <p className="card-subtitle">Active medication compliance monitoring</p>
              </div>
              <button className="btn-text" onClick={() => setCurrentPage('medications')}>
                Open Logs <ChevronRight size={16} />
              </button>
            </div>

            <div className="medications-tracker-widget">
              {medications.map((med) => {
                // For medications with multiple doses vs single dose
                const hasDoses = med.doses && med.doses.length > 0;
                
                return (
                  <div key={med.id} className="med-tracking-row">
                    <div className="med-info-summary">
                      <div className="med-title-block">
                        <span className="med-drug-name">{med.drugName}</span>
                        <span className="med-dosage-label">{med.dosage}</span>
                      </div>
                      <span className="med-patient-tag">{med.patientName}</span>
                    </div>

                    <div className="med-dose-status-row">
                      {hasDoses ? (
                        med.doses.map((dose) => (
                          <div key={dose.id} className="dose-pill-wrapper">
                            <span className="dose-time">{dose.time}</span>
                            {dose.taken ? (
                              <span className="dose-taken-badge">
                                <Check size={12} /> Taken
                              </span>
                            ) : (
                              <button 
                                className="btn-take-dose"
                                onClick={() => onTakeDose(med.id, dose.id)}
                              >
                                Take
                              </button>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="dose-pill-wrapper">
                          <span className="dose-time">{med.time}</span>
                          {med.takenToday ? (
                            <span className="dose-taken-badge">
                              <Check size={12} /> Taken
                            </span>
                          ) : (
                            <button 
                              className="btn-take-dose"
                              onClick={() => onTakeDose(med.id, null)}
                            >
                              Take
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Critical Alerts Widget */}
          <div className="glass-panel content-card alert-summary-card">
            <div className="card-header">
              <h2>Action Items</h2>
            </div>
            <div className="alerts-scroller">
              {reminders.slice(0, 3).map((rem) => (
                <div key={rem.id} className={`alert-indicator-item ${rem.urgency.toLowerCase()}`}>
                  <div className="alert-bullet" />
                  <div className="alert-body">
                    <p className="alert-text">{rem.title}</p>
                    <span className="alert-sub">{rem.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
