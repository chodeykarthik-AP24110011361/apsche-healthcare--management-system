import React, { useState } from 'react';
import {
  FileText,
  Download,
  Calendar,
  Users,
  Pill,
  Activity
} from 'lucide-react';

import './Pages.css';

export default function Reports({
  patients = [],
  appointments = [],
  medications = []
}) {

  const [searchTerm, setSearchTerm] = useState('');

  const normalizedSearch = searchTerm.trim().toLowerCase();

  const filteredPatients = patients.filter(patient =>
    (patient.patientName || '')
      .toLowerCase()
      .includes(normalizedSearch)
  );


  const completedAppointments = appointments.filter(
    appointment =>
      appointment.status === 'Completed' ||
      appointment.status === 'Checked-In'
  ).length;


  const activeMedications = medications.filter(
    medication =>
      medication.status !== 'Deleted' &&
      medication.status !== 'Inactive'
  ).length;


  const lowStockMedications = medications.filter(
    medication =>
      Number(medication.stock) <= 5
  ).length;


  const handleDownloadReport = (patient) => {

    const patientAppointments = appointments.filter(
      appointment =>
        appointment.patientName === patient.patientName
    );


    const patientMedications = medications.filter(
      medication =>
        medication.patientName === patient.patientName
    );


    const report = `
RK HEALTH — CLINICAL PATIENT REPORT

Generated:
${new Date().toLocaleString()}


PATIENT INFORMATION
-------------------

Patient ID:
${patient.id || 'N/A'}

Name:
${patient.patientName || 'N/A'}

Age:
${patient.age || 'N/A'}

Gender:
${patient.gender || 'N/A'}

Blood Group:
${patient.bloodGroup || 'N/A'}

Phone:
${patient.phone || 'N/A'}

Email:
${patient.email || 'N/A'}


CLINICAL INFORMATION
--------------------

Allergies:
${patient.allergies || 'None recorded'}

Medical Conditions:
${patient.conditions || 'None recorded'}

Last Visit:
${patient.lastVisit || 'N/A'}

Clinical Notes:
${patient.notes || 'No clinical notes recorded'}


APPOINTMENT HISTORY
-------------------

Total Appointments:
${patientAppointments.length}

${patientAppointments.length > 0
  ? patientAppointments.map(appointment => `
Date: ${appointment.date || 'N/A'}
Time: ${appointment.time || 'N/A'}
Doctor: ${appointment.doctorName || 'N/A'}
Department: ${appointment.department || 'N/A'}
Status: ${appointment.status || 'N/A'}
`).join('\n')
  : 'No appointments recorded.'
}


MEDICATION HISTORY
------------------

Total Medications:
${patientMedications.length}

${patientMedications.length > 0
  ? patientMedications.map(medication => `
Medication: ${medication.drugName || 'N/A'}
Dosage: ${medication.dosage || 'N/A'}
Frequency: ${medication.frequency || 'N/A'}
Stock Remaining: ${medication.stock ?? 'N/A'}
Status: ${medication.status || 'N/A'}
`).join('\n')
  : 'No medications recorded.'
}


DISCLAIMER
----------

This report is generated from records stored in RK Health.

It is intended for administrative and informational purposes only.

It does not provide medical diagnosis or treatment recommendations.
`;


    const blob = new Blob(
      [report],
      {
        type: 'text/plain;charset=utf-8'
      }
    );


    const url =
      URL.createObjectURL(blob);


    const link =
      document.createElement('a');


    link.href = url;

    link.download =
      `${patient.patientName || 'patient'}-clinical-report.txt`;


    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  };


  return (

    <div className="reports-page animate-fade-in">


      <h2
        style={{
          fontSize: '1.05rem',
          fontWeight: '700',
          marginBottom: '16px',
          color: 'var(--text-primary)'
        }}
      >

        Clinical Analytics

      </h2>


      <div className="stats-grid">


        <div className="glass-panel stat-card">

          <div className="stat-card-header">

            <div className="stat-icon-wrapper blue">

              <Users size={22} />

            </div>

          </div>


          <div className="stat-card-content">

            <h3 className="stat-value">

              {patients.length}

            </h3>

            <p className="stat-label">

              Patient Records

            </p>

            <p className="stat-subtext">

              Stored clinical profiles

            </p>

          </div>

        </div>



        <div className="glass-panel stat-card">

          <div className="stat-card-header">

            <div className="stat-icon-wrapper green">

              <Calendar size={22} />

            </div>

          </div>


          <div className="stat-card-content">

            <h3 className="stat-value">

              {appointments.length}

            </h3>

            <p className="stat-label">

              Total Appointments

            </p>

            <p className="stat-subtext">

              {completedAppointments} checked-in or completed

            </p>

          </div>

        </div>



        <div className="glass-panel stat-card">

          <div className="stat-card-header">

            <div className="stat-icon-wrapper teal">

              <Pill size={22} />

            </div>

          </div>


          <div className="stat-card-content">

            <h3 className="stat-value">

              {activeMedications}

            </h3>

            <p className="stat-label">

              Active Medications

            </p>

            <p className="stat-subtext">

              {lowStockMedications} low-stock prescriptions

            </p>

          </div>

        </div>



        <div className="glass-panel stat-card">

          <div className="stat-card-header">

            <div className="stat-icon-wrapper orange">

              <Activity size={22} />

            </div>

          </div>


          <div className="stat-card-content">

            <h3 className="stat-value">

              {
                patients.length +
                appointments.length +
                medications.length
              }

            </h3>

            <p className="stat-label">

              Clinical Records

            </p>

            <p className="stat-subtext">

              Total synchronized records

            </p>

          </div>

        </div>


      </div>



      <div
        className="glass-panel content-card"
        style={{
          marginTop: '24px'
        }}
      >


        <div className="card-header">

          <div>

            <h2>

              Patient Health Reports

            </h2>

            <p className="card-subtitle">

              Generate reports from synchronized clinical records

            </p>

          </div>

        </div>



        <div
          className="search-wrapper"
          style={{
            display: 'flex',
            width: '300px',
            marginBottom: '20px'
          }}
        >

          <input

            type="text"

            placeholder="Search patient reports..."

            className="search-input"

            value={searchTerm}

            onChange={event =>
              setSearchTerm(event.target.value)
            }

          />

        </div>



        <div className="table-responsive">


          <table className="widget-table">


            <thead>

              <tr>

                <th>Patient</th>

                <th>Last Visit</th>

                <th>Appointments</th>

                <th>Medications</th>

                <th>Clinical Status</th>

                <th>Action</th>

              </tr>

            </thead>



            <tbody>


              {filteredPatients.length === 0 ? (

                <tr>

                  <td
                    colSpan="6"
                    style={{
                      textAlign: 'center',
                      padding: '30px'
                    }}
                  >

                    No patient health records found.

                  </td>

                </tr>

              ) : (


                filteredPatients.map(patient => {


                  const patientAppointments =
                    appointments.filter(
                      appointment =>
                        appointment.patientName ===
                        patient.patientName
                    );


                  const patientMedications =
                    medications.filter(
                      medication =>
                        medication.patientName ===
                        patient.patientName
                    );


                  return (

                    <tr key={patient.id}>


                      <td>

                        <div
                          style={{
                            display: 'flex',
                            alignItems: 'center',
                            gap: '10px'
                          }}
                        >

                          <div
                            className="stat-icon-wrapper blue"
                            style={{
                              width: '36px',
                              height: '36px',
                              borderRadius: '8px'
                            }}
                          >

                            <FileText size={18} />

                          </div>


                          <span
                            style={{
                              fontWeight: '700'
                            }}
                          >

                            {patient.patientName}

                          </span>

                        </div>

                      </td>



                      <td>

                        {patient.lastVisit || 'N/A'}

                      </td>



                      <td>

                        {patientAppointments.length}

                      </td>



                      <td>

                        {patientMedications.length}

                      </td>



                      <td>

                        <span className="badge badge-success">

                          Record Available

                        </span>

                      </td>



                      <td>

                        <button

                          className="btn btn-sm btn-primary-light"

                          onClick={() =>
                            handleDownloadReport(patient)
                          }

                        >

                          <Download size={12} />

                          Download Report

                        </button>

                      </td>


                    </tr>

                  );

                })

              )}


            </tbody>


          </table>


        </div>


      </div>


    </div>

  );

}