import React, { useState } from 'react';

import { Plus, Search, Calendar, User, Clock, Trash2, X, AlertCircle, ExternalLink } from 'lucide-react';
import { mockPatients } from '../mockData';
import './Pages.css';

export default function Appointments({ 
  appointments, 
  onAddAppointment, 
  onCheckIn, 
  onCancelAppointment 
}) {
  const [filterStatus, setFilterStatus] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [patientName, setPatientName] = useState('');
  const [doctorName, setDoctorName] = useState('');
  const [department, setDepartment] = useState('General Medicine');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [notes, setNotes] = useState('');
  const [phone, setPhone] = useState('');

  const handleAddToGoogleCalendar = (appointment) => {
  if (!appointment?.date || !appointment?.time) {
    alert('Appointment date or time is missing.');
    return;
  }

  const start = new Date(
    `${appointment.date}T${appointment.time}`
  );

  if (Number.isNaN(start.getTime())) {
    alert('Invalid appointment date or time.');
    return;
  }

  const end = new Date(
    start.getTime() + 30 * 60 * 1000
  );

  const formatGoogleDate = (dateValue) =>
    dateValue
      .toISOString()
      .replace(/[-:]/g, '')
      .replace(/\.\d{3}Z$/, 'Z');

  const title =
    `RK Health Appointment - ${appointment.patientName || 'Patient'}`;

  const details =
    `Doctor: ${appointment.doctorName || 'N/A'}\n` +
    `Department: ${appointment.department || 'N/A'}\n` +
    `Notes: ${appointment.notes || 'None'}`;

  const calendarUrl =
    'https://calendar.google.com/calendar/render?action=TEMPLATE' +
    `&text=${encodeURIComponent(title)}` +
    `&dates=${formatGoogleDate(start)}/${formatGoogleDate(end)}` +
    `&details=${encodeURIComponent(details)}`;

  window.open(
    calendarUrl,
    '_blank',
    'noopener,noreferrer'
  );
};

  // Handle Form Submission
 const handleSubmit = async (e) => {
    e.preventDefault();
    if (
  !patientName.trim() ||
  !doctorName.trim() ||
  !date ||
  !time
) {
  alert('Please fill in Patient Name, Doctor Name, Date, and Time.');
  return;
}

if (patientName.trim().length < 2) {
  alert('Patient name must contain at least 2 characters.');
  return;
}

if (doctorName.trim().length < 2) {
  alert('Doctor name must contain at least 2 characters.');
  return;
}

const appointmentDateTime = new Date(`${date}T${time}`);

if (
  Number.isNaN(appointmentDateTime.getTime()) ||
  appointmentDateTime <= new Date()
) {
  alert('Appointment date and time must be in the future.');
  return;
}

const newApt = {
  id: `APT-0${appointments.length + 1}`,
  patientName,
  patientId: `P-10${mockPatients.length + 1}`,
  phone: phone.trim(),
  doctorName,
  department,
  date,
  time,
  status: 'Confirmed',
  type: 'Regular Checkup',
  notes
};

await onAddAppointment(newApt);



setPatientName('');
setDoctorName('');
setDepartment(' ');
setDate('');
setTime('');
setNotes('');
setPhone('');
setIsModalOpen(false);


  

  }



  // Filter & Search Logic
  const filteredAppointments = appointments.filter(apt => {
  const search = searchTerm.toLowerCase();

  const matchesSearch =
    (apt.patientName || '').toLowerCase().includes(search) ||
    (apt.doctorName || '').toLowerCase().includes(search) ||
    (apt.department || '').toLowerCase().includes(search);

  const matchesStatus =
    filterStatus === 'All' || apt.status === filterStatus;

  return matchesSearch && matchesStatus;
});

  return (
    <div className="appointments-page animate-fade-in">
      
      {/* Search & Actions Bar */}
      <div className="controls-row">
        <div className="filter-group">
          {['All', 'Confirmed', 'Checked-In', 'Pending', 'Completed', 'Cancelled'].map((status) => (
            <button
              key={status}
              className={`filter-btn ${filterStatus === status ? 'active' : ''}`}
              onClick={() => setFilterStatus(status)}
            >
              {status}
            </button>
          ))}
        </div>

        <button 
          className="btn btn-primary"
          onClick={() => setIsModalOpen(true)}
        >
          <Plus size={18} /> Book Appointment
        </button>
      </div>

      <div className="glass-panel content-card">
        <div className="card-header">
          <div>
            <h2>Appointments Directory</h2>
            <p className="card-subtitle">Showing {filteredAppointments.length} medical schedules</p>
          </div>
          <div className="search-wrapper" style={{ display: 'flex', width: '240px' }}>
            <Search className="search-icon" size={16} />
            <input
  type="tel"
  className="form-input"
  value={phone}
  onChange={(e) => setPhone(e.target.value.trim())}
  placeholder="+917995739633"
  required
/>
          </div>
        </div>

        <div className="table-responsive">
          <table className="widget-table">
            <thead>
              <tr>
                <th>Time & Date</th>
                <th>Patient Details</th>
                <th>Medical Provider</th>
                <th>Specialty</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredAppointments.length === 0 ? (
                <tr>
                  <td colSpan="6">
                    <div className="empty-widget-state">
                      <Calendar size={48} className="empty-icon" />
                      <p>No appointments match your search criteria.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredAppointments.map((apt) => (
                  <tr key={apt.id}>
                    <td>
                      <div className="time-col" style={{ flexDirection: 'column', alignItems: 'flex-start', gap: '2px' }}>
                        <span style={{ fontSize: '0.85rem', fontWeight: '700' }}>{apt.time}</span>
                        <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>{apt.date}</span>
                      </div>
                    </td>
                    <td>
                      <div className="patient-cell">
                        <span className="patient-name">{apt.patientName}</span>
                        <span className="patient-id">{apt.patientId}</span>
                      </div>
                    </td>
                    <td>
                      <div className="patient-cell">
                        <span className="patient-name">{apt.doctorName}</span>
                        <span className="patient-id" style={{ textTransform: 'uppercase', fontSize: '0.65rem' }}>{apt.type}</span>
                      </div>
                    </td>
                    <td>
                      <span className="dept-name">{apt.department}</span>
                    </td>
                    <td>
                      <span className={`badge ${
                        apt.status === 'Completed' ? 'badge-success' : 
                        apt.status === 'Checked-In' ? 'badge-info' : 
                        apt.status === 'Cancelled' ? 'badge-danger' : 
                        'badge-warning'
                      }`}>
                        {apt.status}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        {apt.status === 'Confirmed' && (
                          <button
                            className="btn btn-sm btn-primary-light"
                            onClick={() => onCheckIn(apt.id)}
>
  Check In
</button>
)}

<button
  className="btn btn-sm btn-secondary"
  onClick={() => handleAddToGoogleCalendar(apt)}
>
  <ExternalLink size={14} />
  Add to Calendar
</button>

{apt.status !== 'Cancelled' && apt.status !== 'Completed' && (
  <button
    className="btn btn-sm btn-secondary"
    style={{
      color: 'var(--danger)',
      borderColor: 'rgba(239, 68, 68, 0.2)'
    }}
    onClick={() => onCancelAppointment(apt.id)}
    title="Cancel Appointment"
  >
    Cancel
  </button>
)}
                        {apt.notes && (
                          <div 
                            title={apt.notes} 
                            style={{ display: 'flex', alignItems: 'center', cursor: 'help', color: 'var(--text-muted)' }}
                          >
                            <AlertCircle size={18} />
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Book Appointment Modal */}
      {isModalOpen && (
        <div className="modal-backdrop">
          <div className="modal-content glass-panel">
            <div className="modal-header">
              <h2>Schedule New Appointment</h2>
              <button className="close-btn" onClick={() => setIsModalOpen(false)}>
                <X size={18} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Patient Name</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="e.g. Sarah Jenkins"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Doctor Name</label>
                <input 
                  type="text" 
                  className="form-input" 
                  placeholder="e.g. Dr. Jane Myers"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  required
                />
              </div>

              <div className="settings-form-row">
                <div className="form-group">
                  <label className="form-label">Department</label>
                  <select 
                    className="form-select" 
                    style={{ width: '100%', padding: '10px' }}
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                  >
                    <option value="General Medicine">General Medicine</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Endocrinology">Endocrinology</option>
                    <option value="Pulmonology">Pulmonology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Diagnostics">Diagnostics</option>
                  </select>
                </div>
                
                <div className="form-group">
                  <label className="form-label">Appointment Time</label>
                  <input 
                    type="time" 
                    className="form-input"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Appointment Date</label>
                <input 
                  type="date" 
                  className="form-input"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>

              <div className="form-group">
  <label className="form-label">Patient Phone Number</label>

  <input
    type="tel"
    className="form-input"
    placeholder="+917995739633"
    value={phone}
    onChange={(e) => setPhone(e.target.value)}
    required
  />
</div>

              <div className="form-group">
                <label className="form-label">Consultation Notes (Optional)</label>
                <textarea 
                  className="form-input" 
                  rows="3" 
                  placeholder="Symptom descriptions or checkup instructions..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  Confirm Booking
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
