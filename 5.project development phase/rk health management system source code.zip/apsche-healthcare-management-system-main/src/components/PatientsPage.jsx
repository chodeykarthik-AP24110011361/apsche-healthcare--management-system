import React, { useState } from 'react';
import {
  Plus,
  Search,
  UserRound,
  Pencil,
  Trash2,
  X,
  Eye,
  Download
} from 'lucide-react';

import './Pages.css';

export default function Patients({
  patients = [],
  onAddPatient,
  onUpdatePatient,
  onDeletePatient,
  onGenerateHealthSummary
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewPatient, setViewPatient] = useState(null);
  const [editingPatient, setEditingPatient] = useState(null);
  const [aiSummary, setAiSummary] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const emptyForm = {
    patientName: '',
    age: '',
    gender: '',
    bloodGroup: '',
    phone: '',
    email: '',
    allergies: '',
    conditions: '',
    lastVisit: '',
    notes: ''
  };

  const [form, setForm] = useState(emptyForm);

  const handleChange = (e) => {
    const { name, value } = e.target;

    setForm(previous => ({
      ...previous,
      [name]: value
    }));
  };

  const openAddModal = () => {
    setEditingPatient(null);
    setForm(emptyForm);
    setIsModalOpen(true);
  };

  const openEditModal = (patient) => {
    setEditingPatient(patient);

    setForm({
      patientName: patient.patientName || '',
      age: patient.age || '',
      gender: patient.gender || '',
      bloodGroup: patient.bloodGroup || '',
      phone: patient.phone || '',
      email: patient.email || '',
      allergies: patient.allergies || '',
      conditions: patient.conditions || '',
      lastVisit: patient.lastVisit || '',
      notes: patient.notes || ''
    });

    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingPatient(null);
    setForm(emptyForm);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.patientName.trim()) {
      alert('Patient name is required.');
      return;
    }

    if (
      form.age &&
      (Number(form.age) < 0 || Number(form.age) > 120)
    ) {
      alert('Enter a valid patient age.');
      return;
    }

    if (editingPatient) {
      await onUpdatePatient(
        editingPatient.id,
        form
      );
    } else {
      await onAddPatient({
        id: `PAT-${Date.now()}`,
        ...form
      });
    }

    closeModal();
  };

  const handleDelete = async (patientId) => {
    const confirmed = window.confirm(
      'Delete this patient health record?'
    );

    if (!confirmed) return;

    await onDeletePatient(patientId);
  };

  const handleDownloadReport = () => {
  if (!viewPatient) return;

  const report = `
RK HEALTH — PATIENT HEALTH REPORT

Generated: ${new Date().toLocaleString()}

PATIENT INFORMATION
-------------------
Patient ID: ${viewPatient.id || 'N/A'}
Name: ${viewPatient.patientName || 'N/A'}
Age: ${viewPatient.age || 'N/A'}
Gender: ${viewPatient.gender || 'N/A'}
Blood Group: ${viewPatient.bloodGroup || 'N/A'}
Phone: ${viewPatient.phone || 'N/A'}
Email: ${viewPatient.email || 'N/A'}

CLINICAL INFORMATION
--------------------
Allergies: ${viewPatient.allergies || 'None recorded'}
Medical Conditions: ${viewPatient.conditions || 'None recorded'}
Last Visit: ${viewPatient.lastVisit || 'N/A'}
Clinical Notes: ${viewPatient.notes || 'No notes recorded'}

AI HEALTH SUMMARY
-----------------
${aiSummary || 'AI health summary was not generated for this report.'}

DISCLAIMER
----------
This report is for informational and administrative purposes only.
The AI-generated summary does not provide a medical diagnosis or treatment recommendation.
`;

  const blob = new Blob([report], {
    type: 'text/plain;charset=utf-8'
  });

  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');

  link.href = url;
  link.download = `${viewPatient.patientName || 'patient'}-health-report.txt`;

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
};

  const search = searchTerm
    .trim()
    .toLowerCase();

  const filteredPatients = patients.filter(patient => {
    const name = String(
      patient.patientName || ''
    ).toLowerCase();

    const phone = String(
      patient.phone || ''
    ).toLowerCase();

    const condition = String(
      patient.conditions || ''
    ).toLowerCase();

    return (
      name.includes(search) ||
      phone.includes(search) ||
      condition.includes(search)
    );
  });

  return (
    <div className="patients-page animate-fade-in">

      <div className="controls-row">

        <div
          className="search-wrapper"
          style={{
            display: 'flex',
            width: '340px'
          }}
        >
          <Search
            className="search-icon"
            size={16}
          />

          <input
            className="search-input"
            placeholder="Search patients..."
            value={searchTerm}
            onChange={(e) =>
              setSearchTerm(e.target.value)
            }
          />
        </div>

        <button
          className="btn btn-primary"
          onClick={openAddModal}
        >
          <Plus size={18} />
          Add Patient
        </button>

      </div>


      <div
        className="stats-grid"
        style={{
          gridTemplateColumns:
            'repeat(auto-fill, minmax(330px, 1fr))',
          gap: '20px'
        }}
      >

        {filteredPatients.length === 0 ? (

          <div
            className="glass-panel content-card"
            style={{
              gridColumn: '1 / -1',
              minHeight: '220px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <div className="empty-widget-state">
              <UserRound
                size={48}
                className="empty-icon"
              />

              <p>
                No patient health records found.
              </p>
            </div>
          </div>

        ) : (

          filteredPatients.map(patient => (

            <div
              key={patient.id}
              className="glass-panel content-card stat-card"
              style={{
                display: 'block',
                padding: '20px'
              }}
            >

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  gap: '12px',
                  marginBottom: '18px'
                }}
              >

                <div
                  style={{
                    display: 'flex',
                    gap: '12px',
                    alignItems: 'center'
                  }}
                >

                  <div
                    className="stat-icon-wrapper blue"
                    style={{
                      width: '42px',
                      height: '42px'
                    }}
                  >
                    <UserRound size={21} />
                  </div>

                  <div>
                    <h3
                      style={{
                        color: 'var(--text-primary)',
                        fontSize: '1rem',
                        fontWeight: '800'
                      }}
                    >
                      {patient.patientName}
                    </h3>

                    <p
                      style={{
                        color: 'var(--text-muted)',
                        fontSize: '0.75rem'
                      }}
                    >
                      Patient ID: {patient.id}
                    </p>
                  </div>

                </div>


                <span className="badge badge-info">
                  {patient.bloodGroup || 'N/A'}
                </span>

              </div>


              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '12px',
                  marginBottom: '18px'
                }}
              >

                <div>
                  <p className="stat-subtext">
                    Age
                  </p>

                  <strong>
                    {patient.age || '--'}
                  </strong>
                </div>


                <div>
                  <p className="stat-subtext">
                    Gender
                  </p>

                  <strong>
                    {patient.gender || '--'}
                  </strong>
                </div>


                <div>
                  <p className="stat-subtext">
                    Condition
                  </p>

                  <strong>
                    {patient.conditions || 'None'}
                  </strong>
                </div>


                <div>
                  <p className="stat-subtext">
                    Last Visit
                  </p>

                  <strong>
                    {patient.lastVisit || '--'}
                  </strong>
                </div>

              </div>


              <div
                style={{
                  display: 'flex',
                  gap: '8px',
                  flexWrap: 'wrap',
                  borderTop:
                    '1px solid var(--border)',
                  paddingTop: '14px'
                }}
              >

                <button
                  className="btn btn-sm btn-primary-light"
                  onClick={() =>
                    setViewPatient(patient)
                  }
                >
                  <Eye size={14} />
                  View Record
                </button>
                
                <button
  className="btn btn-sm btn-primary"
  disabled={isGenerating}
  onClick={async () => {
    setIsGenerating(true);
    setAiSummary('');

    const summary =
      await onGenerateHealthSummary(patient);

    if (summary) {
      setViewPatient(patient);
      setAiSummary(summary);
    }

    setIsGenerating(false);
  }}
>
  {isGenerating ? 'Generating...' : 'Generate AI Summary'}
</button>

                <button
                  className="btn btn-sm btn-secondary"
                  onClick={() =>
                    openEditModal(patient)
                  }
                >
                  <Pencil size={14} />
                  Edit
                </button>


                <button
                  className="btn btn-sm btn-secondary"
                  style={{
                    color: 'var(--danger)'
                  }}
                  onClick={() =>
                    handleDelete(patient.id)
                  }
                >
                  <Trash2 size={14} />
                  Delete
                </button>

              </div>

            </div>

          ))

        )}

      </div>


      {isModalOpen && (

        <div className="modal-backdrop">

          <div
            className="modal-content glass-panel"
            style={{
              maxHeight: '90vh',
              overflowY: 'auto'
            }}
          >

            <div className="modal-header">

              <h2>
                {editingPatient
                  ? 'Edit Patient Health Record'
                  : 'Add Patient Health Record'}
              </h2>

              <button
                className="close-btn"
                onClick={closeModal}
              >
                <X size={18} />
              </button>

            </div>


            <form onSubmit={handleSubmit}>

              <div className="form-group">
                <label className="form-label">
                  Patient Name
                </label>

                <input
                  name="patientName"
                  className="form-input"
                  value={form.patientName}
                  onChange={handleChange}
                  required
                />
              </div>


              <div className="settings-form-row">

                <div className="form-group">
                  <label className="form-label">
                    Age
                  </label>

                  <input
                    name="age"
                    type="number"
                    min="0"
                    max="120"
                    className="form-input"
                    value={form.age}
                    onChange={handleChange}
                  />
                </div>


                <div className="form-group">
                  <label className="form-label">
                    Gender
                  </label>

                  <select
                    name="gender"
                    className="form-select"
                    style={{
                      width: '100%',
                      padding: '10px'
                    }}
                    value={form.gender}
                    onChange={handleChange}
                  >
                    <option value="">
                      Select
                    </option>

                    <option value="Male">
                      Male
                    </option>

                    <option value="Female">
                      Female
                    </option>

                    <option value="Other">
                      Other
                    </option>
                  </select>
                </div>

              </div>


              <div className="settings-form-row">

                <div className="form-group">
                  <label className="form-label">
                    Blood Group
                  </label>

                  <input
                    name="bloodGroup"
                    className="form-input"
                    placeholder="e.g. O+"
                    value={form.bloodGroup}
                    onChange={handleChange}
                  />
                </div>


                <div className="form-group">
                  <label className="form-label">
                    Phone
                  </label>

                  <input
                    name="phone"
                    className="form-input"
                    value={form.phone}
                    onChange={handleChange}
                  />
                </div>

              </div>


              <div className="form-group">
                <label className="form-label">
                  Email
                </label>

                <input
                  name="email"
                  type="email"
                  className="form-input"
                  value={form.email}
                  onChange={handleChange}
                />
              </div>


              <div className="form-group">
                <label className="form-label">
                  Allergies
                </label>

                <input
                  name="allergies"
                  className="form-input"
                  value={form.allergies}
                  onChange={handleChange}
                />
              </div>


              <div className="form-group">
                <label className="form-label">
                  Medical Conditions
                </label>

                <input
                  name="conditions"
                  className="form-input"
                  value={form.conditions}
                  onChange={handleChange}
                />
              </div>


              <div className="form-group">
                <label className="form-label">
                  Last Visit
                </label>

                <input
                  name="lastVisit"
                  type="date"
                  className="form-input"
                  value={form.lastVisit}
                  onChange={handleChange}
                />
              </div>


              <div className="form-group">
                <label className="form-label">
                  Clinical Notes
                </label>

                <textarea
                  name="notes"
                  rows="3"
                  className="form-input"
                  value={form.notes}
                  onChange={handleChange}
                />
              </div>


              <div className="modal-footer">

                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={closeModal}
                >
                  Cancel
                </button>


                <button
                  type="submit"
                  className="btn btn-primary"
                >
                  {editingPatient
                    ? 'Save Changes'
                    : 'Create Patient Record'}
                </button>

              </div>

            </form>

          </div>

        </div>

      )}


      {viewPatient && (

        <div className="modal-backdrop">

          <div className="modal-content glass-panel">

            <div className="modal-header">

              <h2>
                Patient Health Record
              </h2>

              <button
                className="close-btn"
                onClick={() =>
                  setViewPatient(null)
                }
              >
                <X size={18} />
              </button>

            </div>


            <div
              style={{
                display: 'grid',
                gap: '14px'
              }}
            >

              <p>
                <strong>Name:</strong>{' '}
                {viewPatient.patientName}
              </p>

              <p>
                <strong>Age:</strong>{' '}
                {viewPatient.age || '--'}
              </p>

              <p>
                <strong>Gender:</strong>{' '}
                {viewPatient.gender || '--'}
              </p>

              <p>
                <strong>Blood Group:</strong>{' '}
                {viewPatient.bloodGroup || '--'}
              </p>

              <p>
                <strong>Phone:</strong>{' '}
                {viewPatient.phone || '--'}
              </p>

              <p>
                <strong>Email:</strong>{' '}
                {viewPatient.email || '--'}
              </p>

              <p>
                <strong>Allergies:</strong>{' '}
                {viewPatient.allergies || 'None'}
              </p>

              <p>
                <strong>Medical Conditions:</strong>{' '}
                {viewPatient.conditions || 'None'}
              </p>

              <p>
                <strong>Last Visit:</strong>{' '}
                {viewPatient.lastVisit || '--'}
              </p>

              <p>
                <strong>Clinical Notes:</strong>{' '}
                {viewPatient.notes || 'No notes'}
              </p>
              
            {aiSummary && (
  <div
    style={{
      marginTop: '18px',
      padding: '16px',
      borderRadius: '8px',
      background: 'var(--background)',
      whiteSpace: 'pre-wrap',
      lineHeight: '1.6'
    }}
  >
    <strong>AI Health Summary</strong>

    <p style={{ marginTop: '10px' }}>
      {aiSummary}
    </p>
  </div>
)}

<button
  className="btn btn-primary"
  onClick={handleDownloadReport}
  style={{
    marginTop: '18px',
    width: '100%'
  }}
>
  <Download size={16} />
  Download Patient Report
</button>

            </div>

          </div>

        </div>

      )}

    </div>
  );
}