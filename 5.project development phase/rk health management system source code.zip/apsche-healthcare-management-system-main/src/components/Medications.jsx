import React, { useState } from 'react';
import {
  Plus,
  Search,
  Pill,
  Check,
  RefreshCw,
  X,
  MessageSquare,
  Clock,
  Trash2
} from 'lucide-react';

import './Pages.css';

export default function Medications({
  medications = [],
  onAddMedication,
  onTakeDose,
  onRefillMedication,
  onDeleteMedication
}) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [patientName, setPatientName] = useState('');
  const [drugName, setDrugName] = useState('');
  const [dosage, setDosage] = useState('');
  const [frequency, setFrequency] = useState('Once daily');
  const [time, setTime] = useState('');
  const [instruction, setInstruction] = useState('');
  const [totalStock, setTotalStock] = useState('30');

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!patientName || !drugName || !dosage || !time) {
      return;
    }

    const uniqueId = `MED-${Date.now()}`;

    const stockValue = Number(totalStock);

    const newMedication = {
      id: uniqueId,
      patientName,
      drugName,
      dosage,
      frequency,
      time,
      instruction,
      stock: stockValue,
      totalStock: stockValue,
      takenToday: false,
      status: 'Active'
    };

    await onAddMedication(newMedication);

    setPatientName('');
    setDrugName('');
    setDosage('');
    setFrequency('Once daily');
    setTime('');
    setInstruction('');
    setTotalStock('30');

    setIsModalOpen(false);
  };

  const search = searchTerm.toLowerCase();

  const filteredMedications = medications.filter((med) => {
    const drug = String(med?.drugName || '').toLowerCase();
    const patient = String(med?.patientName || '').toLowerCase();

    return drug.includes(search) || patient.includes(search);
  });

  return (
    <div className="medications-page animate-fade-in">

      <div className="controls-row">

        <div
          className="search-wrapper"
          style={{
            display: 'flex',
            width: '300px'
          }}
        >
          <Search className="search-icon" size={16} />

          <input
            type="text"
            placeholder="Search medications by drug or patient..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <button
          className="btn btn-primary"
          onClick={() => setIsModalOpen(true)}
        >
          <Plus size={18} />
          Add Prescription
        </button>

      </div>


      <div
        className="stats-grid"
        style={{
          gridTemplateColumns:
            'repeat(auto-fill, minmax(320px, 1fr))',
          gap: '24px'
        }}
      >

        {filteredMedications.length === 0 ? (

          <div
            className="glass-panel content-card"
            style={{
              gridColumn: '1 / -1',
              minHeight: '200px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            <div className="empty-widget-state">
              <Pill size={48} className="empty-icon" />

              <p>
                No medication records found matching search query.
              </p>
            </div>
          </div>

        ) : (

          filteredMedications.map((med) => {

            const stock = Number(med.stock) || 0;

            const total =
              Number(med.totalStock) > 0
                ? Number(med.totalStock)
                : Math.max(stock, 30);

            const isLowStock = stock <= 5;

            const hasDoses =
              Array.isArray(med.doses) &&
              med.doses.length > 0;

            const progressPercent = Math.min(
              100,
              Math.max(
                0,
                Math.round((stock / total) * 100)
              )
            );

            return (

              <div
                key={med.id}
                className="glass-panel content-card stat-card"
                style={{
                  display: 'block',
                  minHeight: 'auto',
                  padding: '20px'
                }}
              >

                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'flex-start',
                    marginBottom: '16px'
                  }}
                >

                  <div
                    style={{
                      display: 'flex',
                      gap: '12px',
                      alignItems: 'center'
                    }}
                  >

                    <div
                      className={`stat-icon-wrapper ${
                        isLowStock ? 'orange' : 'teal'
                      }`}
                      style={{
                        width: '40px',
                        height: '40px'
                      }}
                    >
                      <Pill size={20} />
                    </div>

                    <div>
                      <h3
                        style={{
                          fontSize: '1rem',
                          fontWeight: '800',
                          color: 'var(--text-primary)'
                        }}
                      >
                        {med.drugName || 'Unnamed Medication'}
                      </h3>

                      <span className="med-dosage-label">
                        {med.dosage || 'No dosage'}
                      </span>
                    </div>

                  </div>


                  <span
                    className={`badge ${
                      isLowStock
                        ? 'badge-danger'
                        : 'badge-success'
                    }`}
                  >
                    {isLowStock
                      ? 'Low Stock'
                      : med.status || 'Active'}
                  </span>

                </div>


                <div style={{ marginBottom: '14px' }}>

                  <p
                    style={{
                      fontSize: '0.775rem',
                      color: 'var(--text-muted)',
                      fontWeight: '600'
                    }}
                  >
                    Patient Assignment
                  </p>

                  <p
                    style={{
                      fontSize: '0.85rem',
                      fontWeight: '700',
                      color: 'var(--text-primary)'
                    }}
                  >
                    {med.patientName || 'Unknown Patient'}
                  </p>

                </div>


                <div
                  style={{
                    display: 'flex',
                    gap: '20px',
                    marginBottom: '14px'
                  }}
                >

                  <div>

                    <span
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '4px',
                        fontSize: '0.725rem',
                        color: 'var(--text-muted)',
                        fontWeight: '600'
                      }}
                    >
                      <Clock size={12} />
                      Schedule
                    </span>

                    <span
                      style={{
                        fontSize: '0.8rem',
                        fontWeight: '700',
                        color: 'var(--text-secondary)'
                      }}
                    >
                      {med.frequency || 'Once daily'}
                    </span>

                  </div>


                  <div>

                    <span
                      style={{
                        fontSize: '0.725rem',
                        color: 'var(--text-muted)',
                        fontWeight: '600'
                      }}
                    >
                      Time Slots
                    </span>

                    <div
                      style={{
                        fontSize: '0.8rem',
                        fontWeight: '700',
                        color: 'var(--text-secondary)'
                      }}
                    >
                      {hasDoses
                        ? med.doses
                            .map(dose => dose.time)
                            .join(', ')
                        : med.time || '--'}
                    </div>

                  </div>

                </div>


                {med.instruction && (

                  <div
                    style={{
                      display: 'flex',
                      gap: '6px',
                      backgroundColor: 'var(--background)',
                      padding: '8px 10px',
                      borderRadius: '6px',
                      marginBottom: '16px'
                    }}
                  >

                    <MessageSquare
                      size={14}
                      style={{
                        color: 'var(--primary)',
                        flexShrink: 0,
                        marginTop: '2px'
                      }}
                    />

                    <p
                      style={{
                        fontSize: '0.725rem',
                        color: 'var(--text-secondary)',
                        lineHeight: '1.4'
                      }}
                    >
                      {med.instruction}
                    </p>

                  </div>

                )}


                <div style={{ marginBottom: '20px' }}>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      fontSize: '0.725rem',
                      fontWeight: '600',
                      marginBottom: '4px'
                    }}
                  >

                    <span
                      style={{
                        color: 'var(--text-secondary)'
                      }}
                    >
                      Pills Remaining
                    </span>

                    <span
                      style={{
                        color: isLowStock
                          ? 'var(--danger)'
                          : 'var(--text-primary)'
                      }}
                    >
                      {stock} / {total}
                    </span>

                  </div>


                  <div className="progress-bar-container">

                    <div
                      className={`progress-bar ${
                        isLowStock ? 'orange' : 'teal'
                      }`}
                      style={{
                        width: `${progressPercent}%`
                      }}
                    />

                  </div>

                </div>


                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    gap: '8px',
                    flexWrap: 'wrap',
                    borderTop: '1px solid var(--border)',
                    paddingTop: '14px'
                  }}
                >

                  <div
                    style={{
                      display: 'flex',
                      gap: '6px'
                    }}
                  >

                    <button
                      className="btn btn-sm btn-secondary"
                      onClick={() =>
                        onRefillMedication(med.id)
                      }
                    >
                      <RefreshCw size={12} />
                      Refill
                    </button>


                    <button
                      className="btn btn-sm btn-secondary"
                      onClick={() =>
                        onDeleteMedication(med.id)
                      }
                      style={{
                        color: 'var(--danger)'
                      }}
                    >
                      <Trash2 size={12} />
                      Delete
                    </button>

                  </div>


                  {hasDoses ? (

                    <div
                      style={{
                        display: 'flex',
                        gap: '6px'
                      }}
                    >

                      {med.doses.map((dose) => (

                        dose.taken ? (

                          <span
                            key={dose.id}
                            className="dose-taken-badge"
                          >
                            <Check size={10} />
                            {dose.time}
                          </span>

                        ) : (

                          <button
                            key={dose.id}
                            className="btn-take-dose"
                            onClick={() =>
                              onTakeDose(
                                med.id,
                                dose.id
                              )
                            }
                          >
                            {dose.time}
                          </button>

                        )

                      ))}

                    </div>

                  ) : (

                    <button
                      className="btn btn-sm btn-primary"
                      onClick={() =>
                        onTakeDose(med.id, null)
                      }
                      disabled={stock <= 0}
                    >
                      Log Intake
                    </button>

                  )}

                </div>

              </div>

            );

          })

        )}

      </div>


      {isModalOpen && (

        <div className="modal-backdrop">

          <div className="modal-content glass-panel">

            <div className="modal-header">

              <h2>
                Add New Prescription
              </h2>

              <button
                className="close-btn"
                onClick={() =>
                  setIsModalOpen(false)
                }
              >
                <X size={18} />
              </button>

            </div>


            <form onSubmit={handleSubmit}>


              <div className="form-group">

                <label className="form-label">
                  Patient Name
                </label>

                <input
                  type="text"
                  className="form-input"
                  value={patientName}
                  onChange={(e) =>
                    setPatientName(e.target.value)
                  }
                  required
                />

              </div>


              <div className="form-group">

                <label className="form-label">
                  Medication / Drug Name
                </label>

                <input
                  type="text"
                  className="form-input"
                  value={drugName}
                  onChange={(e) =>
                    setDrugName(e.target.value)
                  }
                  required
                />

              </div>


              <div className="settings-form-row">


                <div className="form-group">

                  <label className="form-label">
                    Dosage Strength
                  </label>

                  <input
                    type="text"
                    className="form-input"
                    value={dosage}
                    onChange={(e) =>
                      setDosage(e.target.value)
                    }
                    required
                  />

                </div>


                <div className="form-group">

                  <label className="form-label">
                    Schedule Timing
                  </label>

                  <input
                    type="text"
                    className="form-input"
                    placeholder="08:00 AM"
                    value={time}
                    onChange={(e) =>
                      setTime(e.target.value)
                    }
                    required
                  />

                </div>


              </div>


              <div className="settings-form-row">


                <div className="form-group">

                  <label className="form-label">
                    Intake Frequency
                  </label>

                  <select
                    className="form-select"
                    style={{
                      width: '100%',
                      padding: '10px'
                    }}
                    value={frequency}
                    onChange={(e) =>
                      setFrequency(e.target.value)
                    }
                  >
                    <option value="Once daily">
                      Once daily
                    </option>

                    <option value="Twice daily">
                      Twice daily
                    </option>

                    <option value="Three times daily">
                      Three times daily
                    </option>

                    <option value="As needed">
                      As needed (PRN)
                    </option>
                  </select>

                </div>


                <div className="form-group">

                  <label className="form-label">
                    Prescription Stock
                  </label>

                  <input
                    type="number"
                    className="form-input"
                    value={totalStock}
                    onChange={(e) =>
                      setTotalStock(e.target.value)
                    }
                    min="1"
                    required
                  />

                </div>


              </div>


              <div className="form-group">

                <label className="form-label">
                  Instructions
                </label>

                <textarea
                  className="form-input"
                  rows="2"
                  value={instruction}
                  onChange={(e) =>
                    setInstruction(e.target.value)
                  }
                />

              </div>


              <div className="modal-footer">

                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() =>
                    setIsModalOpen(false)
                  }
                >
                  Cancel
                </button>


                <button
                  type="submit"
                  className="btn btn-primary"
                >
                  Issue Prescription
                </button>

              </div>


            </form>

          </div>

        </div>

      )}

    </div>
  );
}