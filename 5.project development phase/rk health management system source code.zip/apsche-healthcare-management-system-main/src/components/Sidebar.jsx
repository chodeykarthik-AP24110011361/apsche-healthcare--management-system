import React from 'react';
import { 
  LayoutDashboard, 
  Calendar, 
  Pill,
  Users, 
  FileText, 
  Settings, 
  Heart, 
  X,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import './Sidebar.css';

export default function Sidebar({ 
  currentPage, 
  setCurrentPage, 
  sidebarOpen, 
  setSidebarOpen, 
  sidebarCollapsed, 
  setSidebarCollapsed 
}) {
  const menuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'appointments', label: 'Appointments', icon: Calendar },
  { id: 'medications', label: 'Medications', icon: Pill },
  { id: 'patients', label: 'Patients', icon: Users },
  { id: 'reports', label: 'Reports', icon: FileText },
  { id: 'settings', label: 'Settings', icon: Settings },
];
  const handleNavClick = (pageId) => {
    setCurrentPage(pageId);
    // Close sidebar on mobile after clicking
    if (window.innerWidth <= 768) {
      setSidebarOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="sidebar-overlay" 
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside className={`sidebar glass-panel ${sidebarCollapsed ? 'collapsed' : ''} ${sidebarOpen ? 'mobile-open' : ''}`}>
        {/* Brand Logo Header */}
        <div className="sidebar-header">
          <div className="brand-logo">
            <div className="logo-icon-wrapper">
              <Heart className="logo-icon" fill="currentColor" />
            </div>
            {!sidebarCollapsed && <span className="brand-name">RK Health</span>}
          </div>
          
          {/* Close drawer on mobile */}
          <button 
            className="mobile-close-btn" 
            onClick={() => setSidebarOpen(false)}
            aria-label="Close menu"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="sidebar-nav">
          <ul>
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    className={`nav-link ${isActive ? 'active' : ''}`}
                    onClick={() => handleNavClick(item.id)}
                    title={sidebarCollapsed ? item.label : ''}
                  >
                    <Icon className="nav-icon" size={20} />
                    {!sidebarCollapsed && <span className="nav-label">{item.label}</span>}
                    {isActive && !sidebarCollapsed && <div className="active-indicator" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Sidebar Collapse Toggle Button for Desktop */}
        <div className="sidebar-footer">
          <button 
            className="collapse-toggle-btn"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            title={sidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          >
            {sidebarCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            {!sidebarCollapsed && <span>Collapse Sidebar</span>}
          </button>
        </div>
      </aside>
    </>
  );
}
