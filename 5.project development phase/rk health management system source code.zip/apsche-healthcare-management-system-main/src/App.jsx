import React, { useState, useEffect } from 'react';

import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import Appointments from './components/Appointments';
import Medications from './components/Medications';
import Patients from './components/PatientsPage';
import Reports from './components/Reports';
import Settings from './components/Settings';

import {
  getAppointments,
  addAppointment,
  updateAppointment,
  getMedications,
  addMedication,
  updateMedication,
  deleteMedication,
  getPatients,
  addPatient,
  updatePatient,
  deletePatient,
  generateHealthSummary
} from './api';

import { mockStats } from './mockData';
import './App.css';


export default function App() {

  const [currentPage, setCurrentPage] = useState('dashboard');

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [theme, setTheme] = useState('light');

  const [patients, setPatients] = useState([]);


  const [appointments, setAppointments] = useState([]);

  const [medications, setMedications] = useState([]);

  const [reminders, setReminders] = useState([]);

  const [stats, setStats] = useState(mockStats);

  const [isLoading, setIsLoading] = useState(true);



  /* ==========================================
     THEME
  ========================================== */


  useEffect(() => {

    if (theme === 'dark') {

      document.body.classList.add('dark-theme');

    } else {

      document.body.classList.remove('dark-theme');

    }

  }, [theme]);


  const toggleTheme = () => {

    setTheme(prev =>

      prev === 'light'

        ? 'dark'

        : 'light'

    );

  };



  /* ==========================================
     INITIAL DATA LOADING
  ========================================== */


  useEffect(() => {

    async function loadData() {

      setIsLoading(true);

      try {

        const [

          appointmentsData,

          medicationsData,
          patientsData,

        ] = await Promise.all([

          getAppointments(),

          getMedications(),

          getPatients(),

        ]);


        setAppointments(

          Array.isArray(appointmentsData)

            ? appointmentsData

            : []

        );


        setMedications(

          Array.isArray(medicationsData)

            ? medicationsData

            : []

        );

        setPatients(
  Array.isArray(patientsData)
    ? patientsData
    : []
);

      } catch (error) {

        console.error(

          "Failed loading RK Health data:",

          error

        );

      } finally {

        setIsLoading(false);

      }

    }


    loadData();

  }, []);



  /* ==========================================
     DASHBOARD STATISTICS
  ========================================== */


  useEffect(() => {

    if (isLoading) return;


    const todayStr =

      new Date()

        .toISOString()

        .split('T')[0];


    const todaysAppointments =

      appointments.filter(

        appointment =>

          appointment.date === todayStr

      );


    const completedAppointments =

      todaysAppointments.filter(

        appointment =>

          appointment.status === 'Completed' ||

          appointment.status === 'Checked-In'

      );


    const activeMedications =

      medications.length;


    const lowStockMedications =

      medications.filter(

        medication =>

          Number(medication.stock) <= 5

      ).length;


    const pendingAppointments =

      appointments.filter(

        appointment =>

          appointment.date === todayStr &&

          appointment.status === 'Confirmed'

      ).length;


    setStats(previous => ({

      ...previous,


      todaysAppointments: {

        value:

          todaysAppointments.length,

        completed:

          completedAppointments.length,

        pending:

          todaysAppointments.length -

          completedAppointments.length,

        trend: "normal"

      },


      activeMedications: {

        value:

          activeMedications,

        adherence:

          "92%",

        trend:

          "up"

      },


      upcomingReminders: {

        value:

          pendingAppointments +

          lowStockMedications,

        critical:

          lowStockMedications,

        timeframe:

          "next 3 hours"

      }

    }));



    /* ==========================================
       REMINDERS
    ========================================== */


    const newReminders = [];


    medications.forEach(medication => {

      const stock =

        Number(medication.stock) || 0;


      if (stock <= 5) {

        newReminders.push({

          id:

            `LOW-${medication.id}`,

          type:

            'System',

          title:

            `Low stock: ${medication.drugName}`,

          time:

            `${stock} remaining`,

          urgency:

            'Critical'

        });

      }

    });


    appointments.forEach(appointment => {

      if (

        appointment.date === todayStr &&

        appointment.status === 'Confirmed'

      ) {

        newReminders.push({

          id:

            `APT-${appointment.id}`,

          type:

            'Appointment',

          title:

            `${appointment.patientName} with ${appointment.doctorName}`,

          time:

            appointment.time,

          urgency:

            'Medium'

        });

      }

    });


    setReminders(newReminders);


  }, [

    appointments,

    medications,

    isLoading

  ]);



  /* ==========================================
     APPOINTMENTS
  ========================================== */


  const refreshAppointments = async () => {

    const data =

      await getAppointments();


    setAppointments(

      Array.isArray(data)

        ? data

        : []

    );

  };



  const handleAddAppointment =

    async newAppointment => {

      try {

        await addAppointment(

          newAppointment

        );


        await refreshAppointments();


      } catch (error) {

        console.error(

          "Error adding appointment:",

          error

        );

      }

    };



  const handleCheckIn =

    async appointmentId => {

      try {

        await updateAppointment(

          appointmentId,

          {

            status:

              'Checked-In'

          }

        );


        await refreshAppointments();


      } catch (error) {

        console.error(

          "Error checking in:",

          error

        );

      }

    };



  const handleCancelAppointment =

    async appointmentId => {

      try {

        await updateAppointment(

          appointmentId,

          {

            status:

              'Cancelled'

          }

        );


        await refreshAppointments();


      } catch (error) {

        console.error(

          "Error cancelling appointment:",

          error

        );

      }

    };



  /* ==========================================
     MEDICATIONS
  ========================================== */


  const refreshMedications = async () => {

    const data =

      await getMedications();


    setMedications(

      Array.isArray(data)

        ? data

        : []

    );

  };



  const handleAddMedication =

    async newMedication => {

      try {

        await addMedication(

          newMedication

        );


        await refreshMedications();


      } catch (error) {

        console.error(

          "Error adding medication:",

          error

        );

      }

    };



  const handleTakeDose =

    async (

      medicationId,

      doseId

    ) => {


      const medication =

        medications.find(

          med =>

            med.id === medicationId

        );


      if (!medication) return;


      const currentStock =

        Number(

          medication.stock

        ) || 0;


      if (currentStock <= 0) {

        alert(

          "Cannot log intake. Stock is empty."

        );

        return;

      }


      const updatedFields = {

        stock:

          currentStock - 1

      };


      if (

        doseId &&

        Array.isArray(

          medication.doses

        )

      ) {

        updatedFields.doses =

          medication.doses.map(

            dose =>

              dose.id === doseId

                ? {

                    ...dose,

                    taken:

                      true,

                    takenTime:

                      new Date()

                        .toLocaleTimeString(

                          [],

                          {

                            hour:

                              '2-digit',

                            minute:

                              '2-digit'

                          }

                        )

                  }

                : dose

          );

      }


      try {

        await updateMedication(

          medicationId,

          updatedFields

        );


        await refreshMedications();


      } catch (error) {

        console.error(

          "Error logging intake:",

          error

        );

      }

    };



  const handleRefillMedication =

    async medicationId => {


      const medication =

        medications.find(

          med =>

            med.id === medicationId

        );


      if (!medication) return;


      const refillStock =

        Number(

          medication.totalStock

        ) || 30;


      try {

        await updateMedication(

          medicationId,

          {

            stock:

              refillStock,

            status:

              'Active'

          }

        );


        await refreshMedications();


      } catch (error) {

        console.error(

          "Error refilling medication:",

          error

        );

      }

    };



  const handleDeleteMedication =

    async medicationId => {

      const confirmed =

        window.confirm(

          "Delete this prescription?"

        );


      if (!confirmed) return;


      try {

        await deleteMedication(

          medicationId

        );


        await refreshMedications();


      } catch (error) {

        console.error(

          "Error deleting medication:",

          error

        );

      }

    };

    const handleAddPatient = async (newPatient) => {
  try {
    await addPatient(newPatient);
    setPatients(prev => [...prev, newPatient]);
  } catch (err) {
    console.error(err);
    alert('Failed to add patient');
  }
};

const handleUpdatePatient = async (patientId, updatedFields) => {
  try {
    await updatePatient(patientId, updatedFields);

    setPatients(prev =>
      prev.map(patient =>
        patient.id === patientId
          ? { ...patient, ...updatedFields }
          : patient
      )
    );
  } catch (err) {
    console.error(err);
    alert('Failed to update patient');
  }
};

const handleDeletePatient = async (patientId) => {
  try {
    await deletePatient(patientId);

    setPatients(prev =>
      prev.filter(patient => patient.id !== patientId)
    );
  } catch (err) {
    console.error(err);
    alert('Failed to delete patient');
  }
};

const handleGenerateHealthSummary = async (patient) => {
  try {
    const result = await generateHealthSummary(patient);

    if (!result?.success) {
      alert(result?.message || 'Failed to generate AI summary');
      return null;
    }

    return result.summary;

  } catch (error) {
    console.error('AI summary error:', error);
    alert('Failed to generate AI health summary');
    return null;
  }
};


  /* ==========================================
     PAGE RENDERING
  ========================================== */


  const renderPage = () => {


    if (isLoading) {

      return (

        <div

          style={{

            display:

              'flex',

            justifyContent:

              'center',

            alignItems:

              'center',

            height:

              '60vh'

          }}

        >

          <p>

            Synchronizing clinical records...

          </p>

        </div>

      );

    }



    switch (currentPage) {


      case 'dashboard':

        return (

          <Dashboard

            stats={stats}

            appointments={appointments}

            medications={medications}

            reminders={reminders}

            onCheckIn={handleCheckIn}

            onTakeDose={handleTakeDose}

            setCurrentPage={setCurrentPage}

          />

        );


      case 'appointments':

        return (

          <Appointments

            appointments={appointments}

            onAddAppointment={handleAddAppointment}

            onCheckIn={handleCheckIn}

            onCancelAppointment={handleCancelAppointment}

          />

        );


      case 'medications':

        return (

          <Medications

            medications={medications}

            onAddMedication={handleAddMedication}

            onTakeDose={handleTakeDose}

            onRefillMedication={handleRefillMedication}

            onDeleteMedication={handleDeleteMedication}

          />

        );

        case 'patients':

  return (

    <Patients

      patients={patients}

      onAddPatient={handleAddPatient}

      onUpdatePatient={handleUpdatePatient}

      onDeletePatient={handleDeletePatient}

      onGenerateHealthSummary={handleGenerateHealthSummary}

    />

  );

      case 'reports':

  return (

    <Reports
      patients={patients}
      appointments={appointments}
      medications={medications}
    />

  );

      case 'settings':

        return (

          <Settings

            theme={theme}

            toggleTheme={toggleTheme}

          />

        );


      default:

        return (

          <Dashboard

            stats={stats}

            appointments={appointments}

            medications={medications}

            reminders={reminders}

            onCheckIn={handleCheckIn}

            onTakeDose={handleTakeDose}

            setCurrentPage={setCurrentPage}

          />

        );

    }

  };



  /* ==========================================
     APPLICATION UI
  ========================================== */


  return (

    <div

      className={`app-container ${

        sidebarCollapsed

          ? 'sidebar-collapsed'

          : ''

      } ${

        sidebarOpen

          ? 'sidebar-active'

          : ''

      }`}

    >


      <Sidebar

        currentPage={currentPage}

        setCurrentPage={setCurrentPage}

        sidebarOpen={sidebarOpen}

        setSidebarOpen={setSidebarOpen}

        sidebarCollapsed={sidebarCollapsed}

        setSidebarCollapsed={setSidebarCollapsed}

      />


      <div

        className="main-content"

      >


        <Navbar

          currentPage={currentPage}

          setSidebarOpen={setSidebarOpen}

          theme={theme}

          toggleTheme={toggleTheme}

        />


        <main

          className="page-container"

        >

          {renderPage()}

        </main>


      </div>


    </div>

  );

}