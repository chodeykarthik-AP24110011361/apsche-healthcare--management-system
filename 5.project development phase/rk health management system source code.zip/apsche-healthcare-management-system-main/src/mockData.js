// Mock Data for Healthcare Appointment & Medication Reminder System

export const mockStats = {
  totalPatients: {
    value: 1248,
    change: "+8.4%",
    timeframe: "from last month",
    trend: "up"
  },
  todaysAppointments: {
    value: 14,
    completed: 6,
    pending: 8,
    trend: "normal"
  },
  activeMedications: {
    value: 36,
    adherence: "94.2%",
    trend: "up"
  },
  upcomingReminders: {
    value: 5,
    critical: 2,
    timeframe: "next 3 hours"
  }
};

export const mockPatients = [
  { id: "P-101", name: "Sarah Jenkins", age: 34, gender: "Female", bloodGroup: "A+", phone: "+1 (555) 234-5678", email: "sarah.j@email.com", condition: "Hypertension" },
  { id: "P-102", name: "Robert Chen", age: 45, gender: "Male", bloodGroup: "O-", phone: "+1 (555) 876-5432", email: "robert.c@email.com", condition: "Type 2 Diabetes" },
  { id: "P-103", name: "Emily Watson", age: 29, gender: "Female", bloodGroup: "B+", phone: "+1 (555) 345-6789", email: "emily.w@email.com", condition: "Asthma" },
  { id: "P-104", name: "Michael Vance", age: 62, gender: "Male", bloodGroup: "AB+", phone: "+1 (555) 987-6543", email: "michael.v@email.com", condition: "Hypercholesterolemia" },
  { id: "P-105", name: "Amanda Ross", age: 51, gender: "Female", bloodGroup: "O+", phone: "+1 (555) 456-7890", email: "amanda.r@email.com", condition: "Chronic Pain" }
];

export const mockAppointments = [
  {
    id: "APT-001",
    patientName: "Sarah Jenkins",
    patientId: "P-101",
    doctorName: "Dr. Elena Rostova",
    department: "Cardiology",
    date: "2026-07-04",
    time: "09:30 AM",
    status: "Completed",
    type: "Regular Checkup",
    notes: "Follow-up on blood pressure regulation medication."
  },
  {
    id: "APT-002",
    patientName: "Robert Chen",
    patientId: "P-102",
    doctorName: "Dr. Marcus Vance",
    department: "Endocrinology",
    date: "2026-07-04",
    time: "10:45 AM",
    status: "Checked-In",
    type: "Consultation",
    notes: "Reviewing insulin logs and adjusting glucose target levels."
  },
  {
    id: "APT-003",
    patientName: "Emily Watson",
    patientId: "P-103",
    doctorName: "Dr. Sarah Kim",
    department: "Pulmonology",
    date: "2026-07-04",
    time: "01:15 PM",
    status: "Confirmed",
    type: "Diagnostic Test",
    notes: "Spirometry evaluation and inhaler technique review."
  },
  {
    id: "APT-004",
    patientName: "David Miller",
    patientId: "P-106",
    doctorName: "Dr. Alan Mercer",
    department: "General Medicine",
    date: "2026-07-04",
    time: "02:30 PM",
    status: "Confirmed",
    type: "Routine Screening",
    notes: "Annual wellness visit."
  },
  {
    id: "APT-005",
    patientName: "Michael Vance",
    patientId: "P-104",
    doctorName: "Dr. Elena Rostova",
    department: "Cardiology",
    date: "2026-07-04",
    time: "04:00 PM",
    status: "Pending",
    type: "Follow-up",
    notes: "Review cholesterol blood work results."
  },
  {
    id: "APT-006",
    patientName: "Alice Fletcher",
    patientId: "P-107",
    doctorName: "Dr. Gregory House",
    department: "Diagnostics",
    date: "2026-07-05",
    time: "09:00 AM",
    status: "Confirmed",
    type: "Consultation",
    notes: "Investigating unexplained recurring muscle spasms."
  },
  {
    id: "APT-007",
    patientName: "Amanda Ross",
    patientId: "P-105",
    doctorName: "Dr. Jane Myers",
    department: "Neurology",
    date: "2026-07-05",
    time: "11:30 AM",
    status: "Confirmed",
    type: "Therapy Session",
    notes: "Chronic migraine management evaluation."
  }
];

export const mockMedications = [
  {
    id: "MED-001",
    patientName: "Sarah Jenkins",
    patientId: "P-101",
    drugName: "Lisinopril",
    dosage: "10mg",
    frequency: "Once daily",
    time: "08:00 AM",
    instruction: "Take in the morning with water, before or after food.",
    stock: 24,
    totalStock: 30,
    takenToday: true,
    takenTime: "08:15 AM",
    status: "Taken"
  },
  {
    id: "MED-002",
    patientName: "Robert Chen",
    patientId: "P-102",
    drugName: "Metformin",
    dosage: "500mg",
    frequency: "Twice daily",
    time: "08:00 AM, 07:00 PM",
    instruction: "Take with meals to reduce gastrointestinal side effects.",
    stock: 42,
    totalStock: 60,
    doses: [
      { id: "d1", time: "08:00 AM", taken: true, takenTime: "08:05 AM" },
      { id: "d2", time: "07:00 PM", taken: false, status: "Pending" }
    ],
    status: "Active"
  },
  {
    id: "MED-003",
    patientName: "Emily Watson",
    patientId: "P-103",
    drugName: "Albuterol Inhaler",
    dosage: "90mcg / puff",
    frequency: "As needed",
    time: "Every 4-6 hours PRN",
    instruction: "Inhale 2 puffs as needed for shortness of breath or wheezing.",
    stock: 120,
    totalStock: 200,
    takenToday: true,
    takenTime: "11:00 AM",
    status: "Active"
  },
  {
    id: "MED-004",
    patientName: "Michael Vance",
    patientId: "P-104",
    drugName: "Atorvastatin",
    dosage: "20mg",
    frequency: "Once daily at bedtime",
    time: "09:00 PM",
    instruction: "Take in the evening. Avoid consuming grapefruit juice.",
    stock: 5,
    totalStock: 30,
    takenToday: false,
    status: "Low Stock"
  },
  {
    id: "MED-005",
    patientName: "Amanda Ross",
    patientId: "P-105",
    drugName: "Gabapentin",
    dosage: "300mg",
    frequency: "Three times daily",
    time: "08:00 AM, 02:00 PM, 08:00 PM",
    instruction: "May cause drowsiness. Do not drive or operate machinery.",
    stock: 75,
    totalStock: 90,
    doses: [
      { id: "d1", time: "08:00 AM", taken: true, takenTime: "08:10 AM" },
      { id: "d2", time: "02:00 PM", taken: false, status: "Pending" },
      { id: "d3", time: "08:00 PM", taken: false, status: "Pending" }
    ],
    status: "Active"
  }
];

export const mockReminders = [
  { id: "REM-001", type: "Medication", title: "Metformin (Robert Chen)", time: "07:00 PM", urgency: "High" },
  { id: "REM-002", type: "Medication", title: "Atorvastatin (Michael Vance)", time: "09:00 PM", urgency: "Medium" },
  { id: "REM-003", type: "Appointment", title: "Dr. Elena Rostova - Cardiology Review", time: "04:00 PM Today", urgency: "High" },
  { id: "REM-004", type: "System", title: "Prescription Refill Request: Atorvastatin", time: "Urgent", urgency: "Critical" },
  { id: "REM-005", type: "Medication", title: "Gabapentin (Amanda Ross)", time: "02:00 PM Today", urgency: "Medium" }
];

export const mockVitalsHistory = [
  { month: "Jan", bpSystolic: 122, bpDiastolic: 80, bloodSugar: 104, pulseRate: 72 },
  { month: "Feb", bpSystolic: 120, bpDiastolic: 78, bloodSugar: 98, pulseRate: 70 },
  { month: "Mar", bpSystolic: 125, bpDiastolic: 82, bloodSugar: 109, pulseRate: 75 },
  { month: "Apr", bpSystolic: 118, bpDiastolic: 77, bloodSugar: 95, pulseRate: 68 },
  { month: "May", bpSystolic: 119, bpDiastolic: 79, bloodSugar: 101, pulseRate: 71 },
  { month: "Jun", bpSystolic: 121, bpDiastolic: 80, bloodSugar: 102, pulseRate: 73 }
];

export const mockReports = [
  { id: "REP-001", name: "Comprehensive Lipid Panel", date: "2026-06-15", patient: "Michael Vance", status: "Released", pdfSize: "1.2 MB", remarks: "Optimal total cholesterol levels, HDL slightly low." },
  { id: "REP-002", name: "HbA1c Glycated Hemoglobin Test", date: "2026-06-18", patient: "Robert Chen", status: "Released", pdfSize: "840 KB", remarks: "Average glucose level: 140 mg/dL. HbA1c: 6.5%. Stable control." },
  { id: "REP-003", name: "24-Hour Ambulatory Blood Pressure Report", date: "2026-06-25", patient: "Sarah Jenkins", status: "Released", pdfSize: "2.4 MB", remarks: "Shows diurnal dipping. Systolic range 115-132, diastolic 75-88." },
  { id: "REP-004", name: "Pulmonary Function Test (PFT)", date: "2026-06-28", patient: "Emily Watson", status: "In Lab", pdfSize: "N/A", remarks: "Spirometry complete. Plethysmography scheduled." },
  { id: "REP-005", name: "Brain MRI & Neurological Assessment", date: "2026-07-01", patient: "Amanda Ross", status: "Reviewing", pdfSize: "14.8 MB", remarks: "Images processed. Under doctor evaluation." }
];

export const mockUserProfile = {
  name: "Dr. Alexander Ross",
  role: "Medical Clinic Administrator",
  clinic: "St. Jude Wellness Center",
  email: "alexander.ross@stjude.org",
  avatar: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=200",
  notifications: {
    email: true,
    sms: false,
    push: true,
    criticalRemindersOnly: false
  },
  theme: "light",
  systemPreferences: {
    refreshRate: "5 min",
    timeFormat: "12h",
    soundAlerts: true
  }
};
